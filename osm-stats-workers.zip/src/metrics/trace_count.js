// Hypothetically takes GPS traces, returns count
module.exports = function (gpsTraces) {
  return 0;
  // return gpsTraces.length;
};
