# Example - simulator

The simulator creates a few hashtags and simulates users adding data continuously. Each hashtag is associated with a location on the map, simulating a mapathon.

```
npm install
npm start
```